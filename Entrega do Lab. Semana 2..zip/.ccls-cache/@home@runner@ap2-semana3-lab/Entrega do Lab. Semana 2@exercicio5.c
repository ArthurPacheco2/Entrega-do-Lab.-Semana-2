#include <stdio.h>

int main() {
    int numero, somaDivisores = 0, i;

    // Solicita ao usuário que insira um número inteiro
    printf("Escreva um número inteiro: ");
    scanf("%d", &numero);

    // Encontra a soma dos divisores do número
    for (i = 1; i < numero; i++) {
        if (numero % i == 0) {
            somaDivisores += i;
        }
    }

    // Verifica se o número é perfeito e exibe o resultado
    if (somaDivisores == numero) {
        printf("%d é um número inteiro perfeito.\n", numero);
    } else {
        printf("%d NÃO é um número inteiro perfeito.\n", numero);
    }

    return 0;
}
  