#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int numeroSorteado, palpite, tentativas = 0;

    // Inicializa o gerador de números aleatórios
    srand(time(NULL));

    // Sorteia um número entre 1 e 100
    numeroSorteado = rand() % 100 + 1;

    printf("Tente adivinhar o número sorteado (entre 1 e 100):\n");

    do {
        // Solicita o palpite do usuário
        printf("Seu palpite: ");
        scanf("%d", &palpite);

        // Verifica se o palpite é válido
        if (palpite < 1 || palpite > 100) {
            printf("Por favor, entre com um valor válido (entre 1 e 100).\n");
            continue;
        }

        // Incrementa o número de tentativas
        tentativas++;

        // Verifica se o palpite está correto
        if (palpite == numeroSorteado) {
            printf("Parabéns!!! Você acertou em %d tentativas!\n", tentativas);
            break;
        } else if (palpite < numeroSorteado) {
            printf("Você chutou muito baixo! Tente novamente.\n");
        } else {
            printf("Você chutou muito alto! Tente novamente.\n");
        }

        // Verifica se o número de tentativas excedeu o máximo
        if (tentativas >= 5) {
            printf("Você excedeu o número máximo de tentativas. O número sorteado era %d.\n", numeroSorteado);
            break;
        }
    } while (1);

    return 0;
}
