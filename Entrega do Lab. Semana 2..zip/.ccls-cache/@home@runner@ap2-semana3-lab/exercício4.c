Desenvolva um programa que leia um número inteiro e imprima todos os seus divisores. 
Exemplo de execução do programa:
Escreva um número inteiro: 10Os divisores de 10 são: 1 2 5 10
