  #include <stdio.h>

  int main() {
      int numero, i;

      // Solicita ao usuário que insira um número inteiro
      printf("Escreva um número inteiro: ");
      scanf("%d", &numero);

      printf("Os divisores de %d são: ", numero);

      // Encontra e imprime os divisores do número
      for (i = 1; i <= numero; i++) {
          if (numero % i == 0) {
              printf("%d ", i);
          }
      }

      printf("\n");

      return 0;
  }
